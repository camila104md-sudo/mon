#pragma once

// Global simulation time (is advanced in main)
extern double dGlobaleZeit;

// Numerical tolerance (used for floating-point comparisons)
extern const double dEpsilon;
